import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import HomeSection from './components/HomeSection';
import AboutSection from './components/AboutSection';
import SkillsSection from './components/SkillsSection';
import ProjectsSection from './components/ProjectsSection';
import LearningLogSection from './components/LearningLogSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';

// Define TypeScript interfaces for our database records.
// In Python, this is similar to defining a class or a dictionary schema.
interface Project {
  id: number;
  title: string;
  description: string;
  github_url: string;
  tech_used: string;
  difficulty: string;
}

interface Skill {
  id: number;
  name: string;
  category: string;
  status: string;
}

interface Log {
  id: number;
  day_number: number;
  topic: string;
  description: string;
  code_snippet: string;
  learned_at: string;
}

export default function App() {
  // --- STATE VARIABLES ---
  // In Python, you write variables like active_section = "home".
  // In React, we use useState. This returns the current value and a function to update it.
  // When the state changes, the browser automatically re-renders that part of the page!
  const [activeSection, setActiveSection] = useState<string>('home');
  const [projects, setProjects] = useState<Project[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [logs, setLogs] = useState<Log[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // --- FETCHING DATA ---
  // This function fetches our portfolio data from the backend API we wrote in api/portfolio.js.
  // It is an "async" function, meaning it runs in the background without freezing the webpage.
  const fetchPortfolioData = async () => {
    try {
      setLoading(true);
      // Fetch from our local serverless endpoint
      const response = await fetch('/api/portfolio');
      if (!response.ok) {
        throw new Error('Could not fetch portfolio data');
      }
      const data = await response.json();
      
      // Store the fetched records into our React states
      setProjects(data.projects || []);
      setSkills(data.skills || []);
      setLogs(data.logs || []);
    } catch (error) {
      console.error('Error loading portfolio data:', error);
    } finally {
      setLoading(false);
    }
  };

  // --- THE USEEFFECT HOOK ---
  // This hook is like a "main()" function or a startup script.
  // The empty array [] at the end means "run this code exactly once when the website loads".
  useEffect(() => {
    fetchPortfolioData();
  }, []);

  // --- RENDER SECTION HELPER ---
  // This helper function decides which section to display based on the activeSection.
  // This keeps our layout clean and makes it feel like an interactive single-page app!
  const renderActiveSection = () => {
    switch (activeSection) {
      case 'home':
        return <HomeSection setActiveSection={setActiveSection} />;
      case 'about':
        return <AboutSection />;
      case 'skills':
        return <SkillsSection skills={skills} loading={loading} />;
      case 'projects':
        return <ProjectsSection projects={projects} loading={loading} />;
      case 'journal':
        return <LearningLogSection logs={logs} loading={loading} />;
      case 'contact':
        return <ContactSection />;
      default:
        return <HomeSection setActiveSection={setActiveSection} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans antialiased">
      {/* 1. Navbar: The top navigation bar */}
      <Navbar activeSection={activeSection} setActiveSection={setActiveSection} />

      {/* 2. Main Content Area */}
      <main className="flex-grow max-w-4xl mx-auto px-4 sm:px-6 w-full py-8">
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-10 shadow-sm min-h-[500px]">
          {/* We render the active section dynamically */}
          {renderActiveSection()}
        </div>
      </main>

      {/* 3. Footer: The bottom copyright bar */}
      <Footer />
    </div>
  );
}
