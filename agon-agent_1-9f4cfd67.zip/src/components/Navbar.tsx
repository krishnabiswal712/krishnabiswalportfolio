import React from 'react';

// This is a simple Navigation Bar component.
// It is responsive and allows users to jump to different sections of the page.
interface NavbarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

export default function Navbar({ activeSection, setActiveSection }: NavbarProps) {
  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'skills', label: 'Skills' },
    { id: 'projects', label: 'Projects' },
    { id: 'journal', label: 'Python Diary' },
    { id: 'contact', label: 'Contact' }
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-slate-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo / Title */}
          <div className="flex-shrink-0">
            <button 
              onClick={() => setActiveSection('home')}
              className="text-lg font-mono font-bold text-slate-800 hover:text-indigo-600 transition-colors cursor-pointer"
            >
              krishna_biswal<span className="text-indigo-600">.py</span>
            </button>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden md:block">
            <div className="flex space-x-6">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`px-3 py-2 text-sm font-medium transition-all duration-150 cursor-pointer ${
                    activeSection === item.id
                      ? 'text-indigo-600 border-b-2 border-indigo-600'
                      : 'text-slate-600 hover:text-slate-900 hover:border-b-2 hover:border-slate-300'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Mobile Navigation (Scrollable list for simplicity and clean mobile layout) */}
          <div className="block md:hidden overflow-x-auto whitespace-nowrap scrollbar-none py-2 max-w-[240px] sm:max-w-[320px]">
            <div className="flex space-x-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`text-xs font-semibold pb-1 transition-all cursor-pointer ${
                    activeSection === item.id
                      ? 'text-indigo-600 border-b-2 border-indigo-600'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
