import React from 'react';
import { ArrowRight, BookOpen, MessageSquare } from 'lucide-react';

// The HomeSection is the welcoming screen.
// It features a clean introduction, Krishna's learning tagline, and two call-to-action buttons.
interface HomeProps {
  setActiveSection: (section: string) => void;
}

export default function HomeSection({ setActiveSection }: HomeProps) {
  return (
    <section className="py-12 md:py-20 text-left">
      {/* Small beginner greeting badge */}
      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-mono font-medium bg-indigo-50 text-indigo-700 border border-indigo-200 mb-6">
        print("Hello, World!")
      </span>
      
      {/* Main Heading */}
      <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-slate-900 mb-4 font-sans">
        Hi, I'm <span className="text-indigo-600">Krishna Biswal</span>
      </h1>
      
      {/* Tagline */}
      <p className="text-xl sm:text-2xl font-medium text-slate-700 mb-6 font-mono">
        Python Learner & Beginner Developer
      </p>
      
      {/* Short, honest summary */}
      <p className="text-base sm:text-lg text-slate-600 max-w-2xl mb-8 leading-relaxed">
        Welcome to my personal corner of the web! I am a student tracking my journey as I learn 
        programming fundamentals, write simple terminal scripts, and discover how software works. 
        No fancy corporate buzzwords here—just honest learning, code snippets, and beginner projects.
      </p>
      
      {/* Call to action buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <button
          onClick={() => setActiveSection('projects')}
          className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 transition-colors cursor-pointer shadow-sm"
        >
          View My Projects
          <ArrowRight className="ml-2 h-4 w-4" />
        </button>
        
        <button
          onClick={() => setActiveSection('journal')}
          className="inline-flex items-center justify-center px-5 py-3 border border-slate-300 text-base font-medium rounded-md text-slate-700 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
        >
          <BookOpen className="mr-2 h-4 w-4 text-slate-500" />
          Read My Python Diary
        </button>

        <button
          onClick={() => setActiveSection('contact')}
          className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
        >
          <MessageSquare className="mr-2 h-4 w-4 text-slate-500" />
          Contact Me
        </button>
      </div>

      {/* Code background decoration (Minimal, student style) */}
      <div className="mt-12 p-4 bg-slate-50 rounded-lg border border-slate-200 font-mono text-xs text-slate-600">
        <div className="flex items-center space-x-2 mb-2 pb-2 border-b border-slate-200">
          <div className="w-3 h-3 rounded-full bg-red-400"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
          <div className="w-3 h-3 rounded-full bg-green-400"></div>
          <span className="text-slate-400 text-[10px] ml-2">welcome.py</span>
        </div>
        <p className="text-indigo-600">def <span className="text-indigo-800">greet_visitor</span>(name):</p>
        <p className="pl-4 text-slate-500">print(f<span className="text-emerald-600">"Welcome, {"{name}"}! Thanks for checking out my portfolio."</span>)</p>
        <p className="pl-4 text-slate-500">print(<span className="text-emerald-600">"I am currently learning loops, lists, and basic OOP."</span>)</p>
        <p className="mt-2 text-indigo-600">greet_visitor(<span className="text-emerald-600">"Guest"</span>)</p>
      </div>
    </section>
  );
}
