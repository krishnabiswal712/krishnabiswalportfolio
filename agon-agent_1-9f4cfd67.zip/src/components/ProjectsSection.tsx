import React from 'react';
import { Github, Folder, AlertTriangle } from 'lucide-react';

// ProjectsSection shows Krishna's simple beginner projects.
// Descriptions are realistic, highlighting learning outcomes rather than commercial success.
interface Project {
  id: number;
  title: string;
  description: string;
  github_url: string;
  tech_used: string;
  difficulty: string;
}

interface ProjectsProps {
  projects: Project[];
  loading: boolean;
}

export default function ProjectsSection({ projects, loading }: ProjectsProps) {
  return (
    <section className="py-12 text-left">
      {/* Section Header */}
      <div className="border-b border-slate-200 pb-4 mb-8">
        <h2 className="text-3xl font-bold text-slate-900 font-sans">My Projects</h2>
        <p className="text-sm text-indigo-600 font-mono mt-1">ls -la ./projects</p>
      </div>

      <p className="text-slate-600 mb-8 max-w-2xl text-base leading-relaxed">
        These are the small applications I built while learning Python. They are simple, terminal-based 
        projects, but they helped me grasp core concepts like loops, conditionals, functions, and file storage.
      </p>

      {loading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
          <span className="ml-3 font-mono text-sm text-slate-500">Loading projects...</span>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-1">
          {projects.map((project) => (
            <div 
              key={project.id} 
              className="p-6 bg-white rounded-lg border border-slate-200 hover:border-slate-300 transition-all hover:shadow-sm"
            >
              {/* Card Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-indigo-50 rounded text-indigo-600">
                    <Folder className="h-5 w-5" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">{project.title}</h3>
                </div>
                
                {/* Difficulty Badge */}
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-mono font-medium bg-slate-100 text-slate-700 border border-slate-200">
                  {project.difficulty}
                </span>
              </div>

              {/* Description */}
              <p className="text-slate-600 text-sm mb-4 leading-relaxed">
                {project.description}
              </p>

              {/* Technologies used */}
              <div className="mb-4">
                <span className="text-xs font-mono text-slate-400 block mb-1">Built using:</span>
                <span className="inline-block text-xs font-mono bg-slate-50 text-slate-700 border border-slate-200 px-2 py-1 rounded">
                  {project.tech_used}
                </span>
              </div>

              {/* Project Links */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                <a 
                  href={project.github_url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-sm font-mono text-indigo-600 hover:text-indigo-800 transition-colors"
                >
                  <Github className="h-4 w-4 mr-1.5" />
                  View GitHub Repository
                </a>
                
                <span className="text-[11px] font-mono text-slate-400 flex items-center">
                  <AlertTriangle className="h-3 w-3 mr-1 text-amber-500" />
                  Placeholder Link (Will update soon)
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
