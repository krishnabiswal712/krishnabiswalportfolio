import React from 'react';
import { Heart } from 'lucide-react';

// Simple, clean footer with Krishna's copyright and a simple student declaration.
export default function Footer() {
  return (
    <footer className="mt-20 py-8 border-t border-slate-200 text-center text-xs text-slate-500 font-mono">
      <div className="max-w-4xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          © {new Date().getFullYear()} Krishna Biswal. All rights reserved.
        </div>
        
        <div className="flex items-center">
          Made with <Heart className="h-3 w-3 text-red-500 mx-1 animate-pulse" /> & Python learning vibes
        </div>
        
        <div>
          <span className="text-indigo-600">exit()</span>
        </div>
      </div>
    </footer>
  );
}
