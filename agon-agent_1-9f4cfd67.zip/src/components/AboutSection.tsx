import React from 'react';
import { Terminal, Code, Heart, HelpCircle } from 'lucide-react';

// AboutSection provides a genuine, non-inflated introduction.
// It explains who Krishna is and his natural motivations for learning.
export default function AboutSection() {
  return (
    <section className="py-12 text-left">
      {/* Section Header */}
      <div className="border-b border-slate-200 pb-4 mb-8">
        <h2 className="text-3xl font-bold text-slate-900 font-sans">About Me</h2>
        <p className="text-sm text-indigo-600 font-mono mt-1">whoami --info</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 items-start">
        {/* Main Text Content */}
        <div className="md:col-span-2 space-y-6 text-slate-600 text-base leading-relaxed">
          <p>
            Hello! I am <strong className="text-slate-900">Krishna Biswal</strong>. I am a student and a 
            passionate Python learner who recently started their journey into the world of programming.
          </p>
          <p>
            Unlike many portfolios that claim years of expert-level experience, I want to be fully honest: 
            <strong> I am a beginner.</strong> I started coding because I was curious about how computers 
            solve problems. Every day, I am learning how to think programmatically, break down complex logic, 
            and build simple scripts that do useful things.
          </p>
          <p>
            Right now, my learning is centered on <strong className="text-slate-900">Python</strong> because of its clean, 
            readable syntax and its friendly community. I am taking online courses, practicing coding challenges, 
            and learning how to use Git to track my changes.
          </p>
          <p>
            My goal is simple: to build a strong foundation in programming logic, understand basic algorithms, 
            and eventually transition from command-line tools to building web applications or working with data.
          </p>
        </div>

        {/* Side Card: Quick Facts */}
        <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
          <h3 className="text-sm font-mono font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center">
            <Terminal className="h-4 w-4 mr-2 text-indigo-600" />
            Quick Facts
          </h3>
          
          <ul className="space-y-4 text-sm text-slate-600">
            <li className="flex items-start">
              <Code className="h-4 w-4 mr-3 mt-0.5 text-indigo-500 flex-shrink-0" />
              <div>
                <strong className="text-slate-800 block">Current Focus</strong>
                Python basics, simple data structures, and file operations.
              </div>
            </li>
            
            <li className="flex items-start">
              <Heart className="h-4 w-4 mr-3 mt-0.5 text-indigo-500 flex-shrink-0" />
              <div>
                <strong className="text-slate-800 block">Interests</strong>
                Problem solving, automating boring tasks, and learning command-line utilities.
              </div>
            </li>

            <li className="flex items-start">
              <HelpCircle className="h-4 w-4 mr-3 mt-0.5 text-indigo-500 flex-shrink-0" />
              <div>
                <strong className="text-slate-800 block">Why Coding?</strong>
                I love the feeling of writing a few lines of code and seeing the computer carry out commands.
              </div>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}
