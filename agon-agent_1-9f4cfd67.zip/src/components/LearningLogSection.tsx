import React, { useState, useEffect } from 'react';
import { Calendar, Code2, MessageSquare, Send, CheckCircle } from 'lucide-react';

// LearningLogSection provides two tabs:
// 1. "Python Diary" - Displays Krishna's daily logs, showing how he learns.
// 2. "Guestbook" - A real interactive guestbook fetching and pushing messages to Supabase!
interface Log {
  id: number;
  day_number: number;
  topic: string;
  description: string;
  code_snippet: string;
  learned_at: string;
}

interface GuestbookMessage {
  id: number;
  name: string;
  message: string;
}

interface LearningLogProps {
  logs: Log[];
  loading: boolean;
}

export default function LearningLogSection({ logs, loading }: LearningLogProps) {
  const [activeTab, setActiveTab] = useState<'diary' | 'guestbook'>('diary');
  const [guestbook, setGuestbook] = useState<GuestbookMessage[]>([]);
  const [gbLoading, setGbLoading] = useState(false);
  
  // Guestbook Form State
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState('');

  // Fetch guestbook messages
  const fetchGuestbook = async () => {
    setGbLoading(true);
    try {
      const res = await fetch('/api/guestbook');
      if (res.ok) {
        const data = await res.json();
        setGuestbook(data);
      }
    } catch (err) {
      console.error('Error fetching guestbook:', err);
    } finally {
      setGbLoading(false);
    }
  };

  // Load guestbook messages when guestbook tab is selected
  useEffect(() => {
    if (activeTab === 'guestbook') {
      fetchGuestbook();
    }
  }, [activeTab]);

  // Handle guestbook form submission
  const handleSubmitMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setSubmitError('');
    setSubmitSuccess(false);

    if (!name.trim() || !message.trim()) {
      setSubmitError('Please enter both your name and a message.');
      setSubmitting(false);
      return;
    }

    try {
      const res = await fetch('/api/guestbook', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, message }),
      });

      if (res.ok) {
        setSubmitSuccess(true);
        setName('');
        setMessage('');
        // Re-fetch to show the new message at the top
        fetchGuestbook();
      } else {
        const errData = await res.json();
        setSubmitError(errData.error || 'Something went wrong. Please try again.');
      }
    } catch (err) {
      setSubmitError('Failed to send message. Please check your internet connection.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="py-12 text-left">
      {/* Section Header */}
      <div className="border-b border-slate-200 pb-4 mb-6">
        <h2 className="text-3xl font-bold text-slate-900 font-sans">Learning & Community</h2>
        <p className="text-sm text-indigo-600 font-mono mt-1">cat learning_journal.md</p>
      </div>

      {/* Tabs Switcher */}
      <div className="flex border-b border-slate-200 mb-8">
        <button
          onClick={() => setActiveTab('diary')}
          className={`py-3 px-6 text-sm font-medium border-b-2 cursor-pointer transition-all ${
            activeTab === 'diary'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          My Python Diary
        </button>
        <button
          onClick={() => setActiveTab('guestbook')}
          className={`py-3 px-6 text-sm font-medium border-b-2 cursor-pointer transition-all flex items-center ${
            activeTab === 'guestbook'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <MessageSquare className="h-4 w-4 mr-2" />
          Visitor Guestbook ({guestbook.length || '...'})
        </button>
      </div>

      {/* Tab Content 1: My Python Diary */}
      {activeTab === 'diary' && (
        <div className="space-y-8">
          <p className="text-slate-600 text-base leading-relaxed">
            I believe learning in public is one of the best ways to stay motivated. Here is a timeline of my 
            learning diary, showing what concepts I worked on each day.
          </p>

          {loading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
              <span className="ml-3 font-mono text-sm text-slate-500">Loading diary...</span>
            </div>
          ) : (
            <div className="relative border-l-2 border-slate-200 ml-4 pl-6 space-y-8">
              {logs.map((log) => (
                <div key={log.id} className="relative">
                  {/* Timeline Dot */}
                  <span className="absolute -left-[31px] top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-white border-2 border-indigo-600">
                    <span className="h-1.5 w-1.5 rounded-full bg-indigo-600" />
                  </span>

                  {/* Log Content Card */}
                  <div className="p-5 bg-white rounded-lg border border-slate-200">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <span className="text-xs font-mono font-bold text-indigo-600 uppercase">
                        Day {log.day_number}
                      </span>
                      <span className="text-xs text-slate-400 flex items-center font-mono">
                        <Calendar className="h-3 w-3 mr-1" />
                        {log.learned_at}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 mb-2">{log.topic}</h3>
                    <p className="text-sm text-slate-600 mb-4 leading-relaxed">{log.description}</p>

                    {/* Simple Code Snippet Display */}
                    {log.code_snippet && (
                      <div className="bg-slate-900 rounded-md p-4 font-mono text-xs text-slate-200 overflow-x-auto">
                        <div className="flex justify-between items-center text-slate-500 pb-2 mb-2 border-b border-slate-800">
                          <span>Python Code</span>
                          <Code2 className="h-3.5 w-3.5" />
                        </div>
                        <pre className="whitespace-pre">{log.code_snippet}</pre>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab Content 2: Guestbook */}
      {activeTab === 'guestbook' && (
        <div className="space-y-8">
          <p className="text-slate-600 text-base leading-relaxed">
            Are you a fellow learner, a developer, or just passing by? Leave a friendly message below! 
            Your thoughts, tips, or learning advice are highly appreciated.
          </p>

          <div className="grid md:grid-cols-5 gap-8 items-start">
            {/* Left Column: Post Message Form */}
            <div className="md:col-span-2 bg-slate-50 p-5 rounded-lg border border-slate-200">
              <h3 className="text-sm font-mono font-bold text-slate-800 uppercase tracking-wider mb-4">
                Leave a Message
              </h3>

              <form onSubmit={handleSubmitMessage} className="space-y-4">
                <div>
                  <label htmlFor="gb-name" className="block text-xs font-mono font-medium text-slate-500 mb-1">
                    Your Name
                  </label>
                  <input
                    id="gb-name"
                    type="text"
                    required
                    maxLength={50}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Alex"
                    className="w-full text-sm px-3 py-2 bg-white border border-slate-300 rounded shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label htmlFor="gb-message" className="block text-xs font-mono font-medium text-slate-500 mb-1">
                    Message
                  </label>
                  <textarea
                    id="gb-message"
                    required
                    rows={4}
                    maxLength={500}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Write something nice or offer some Python tips!"
                    className="w-full text-sm px-3 py-2 bg-white border border-slate-300 rounded shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 resize-none"
                  />
                </div>

                {submitError && (
                  <p className="text-xs text-red-600 font-mono">{submitError}</p>
                )}

                {submitSuccess && (
                  <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-xs flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2 text-emerald-600 flex-shrink-0" />
                    Message posted! Thank you.
                  </div>
                )}

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded text-white bg-indigo-600 hover:bg-indigo-700 transition-colors disabled:opacity-50 cursor-pointer"
                >
                  {submitting ? 'Posting...' : 'Post Message'}
                  <Send className="ml-2 h-3.5 w-3.5" />
                </button>
              </form>
            </div>

            {/* Right Column: Messages List */}
            <div className="md:col-span-3 space-y-4">
              <h3 className="text-sm font-mono font-bold text-slate-800 uppercase tracking-wider">
                Recent Messages
              </h3>

              {gbLoading && guestbook.length === 0 ? (
                <p className="text-xs font-mono text-slate-400">Loading messages...</p>
              ) : guestbook.length === 0 ? (
                <div className="p-6 text-center border-2 border-dashed border-slate-200 rounded-lg">
                  <p className="text-sm text-slate-400 font-mono">No messages yet. Be the first to leave one!</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[450px] overflow-y-auto pr-2">
                  {guestbook.map((msg) => (
                    <div key={msg.id} className="p-4 bg-white rounded-lg border border-slate-200">
                      <div className="flex justify-between items-center mb-1">
                        <strong className="text-sm text-slate-800">{msg.name}</strong>
                        <span className="text-[10px] font-mono text-slate-400">Visitor #{msg.id}</span>
                      </div>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{msg.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
