import React, { useState } from 'react';
import { Mail, Github, Linkedin, Send, Check } from 'lucide-react';

// ContactSection lists Krishna's actual links and provides a simple contact form.
export default function ContactSection() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    setError('');
    setSent(false);

    if (!name.trim() || !email.trim() || !message.trim()) {
      setError('Please fill in all the fields.');
      setSending(false);
      return;
    }

    try {
      // Send message to our guestbook endpoint as a contact submission
      const res = await fetch('/api/guestbook', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: `${name} (Contact Form: ${email})`,
          message: message,
        }),
      });

      if (res.ok) {
        setSent(true);
        setName('');
        setEmail('');
        setMessage('');
      } else {
        const errData = await res.json();
        setError(errData.error || 'Something went wrong. Please try again.');
      }
    } catch (err) {
      setError('Failed to send message. Please check your network connection.');
    } finally {
      setSending(false);
    }
  };

  return (
    <section className="py-12 text-left">
      {/* Section Header */}
      <div className="border-b border-slate-200 pb-4 mb-8">
        <h2 className="text-3xl font-bold text-slate-900 font-sans">Contact</h2>
        <p className="text-sm text-indigo-600 font-mono mt-1">contact.py --get-in-touch</p>
      </div>

      <div className="grid md:grid-cols-5 gap-8 items-start">
        {/* Left Column: Real Contact details */}
        <div className="md:col-span-2 space-y-6">
          <p className="text-slate-600 text-base leading-relaxed">
            I would love to connect! Whether you have advice on learning Python, want to collaborate on 
            a beginner project, or just want to say hi, feel free to reach out.
          </p>

          <div className="space-y-4">
            {/* Email */}
            <a 
              href="mailto:krishnabiswal712@gmail.com"
              className="flex items-center p-3 bg-white border border-slate-200 rounded-lg hover:border-indigo-500 hover:bg-slate-50/50 transition-all group"
            >
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded group-hover:bg-indigo-100 transition-colors">
                <Mail className="h-5 w-5" />
              </div>
              <div className="ml-3 overflow-hidden">
                <span className="text-xs font-mono text-slate-400 block">Email Address</span>
                <span className="text-sm font-semibold text-slate-800 block truncate">krishnabiswal712@gmail.com</span>
              </div>
            </a>

            {/* GitHub */}
            <a 
              href="https://github.com/krishnabiswal712"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center p-3 bg-white border border-slate-200 rounded-lg hover:border-indigo-500 hover:bg-slate-50/50 transition-all group"
            >
              <div className="p-2 bg-slate-100 text-slate-700 rounded group-hover:bg-slate-200 transition-colors">
                <Github className="h-5 w-5" />
              </div>
              <div className="ml-3 overflow-hidden">
                <span className="text-xs font-mono text-slate-400 block">GitHub Profile</span>
                <span className="text-sm font-semibold text-slate-800 block truncate">github.com/krishnabiswal712</span>
              </div>
            </a>

            {/* LinkedIn */}
            <a 
              href="https://www.linkedin.com/in/krishna-biswal-45a534419"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center p-3 bg-white border border-slate-200 rounded-lg hover:border-indigo-500 hover:bg-slate-50/50 transition-all group"
            >
              <div className="p-2 bg-sky-50 text-sky-600 rounded group-hover:bg-sky-100 transition-colors">
                <Linkedin className="h-5 w-5" />
              </div>
              <div className="ml-3 overflow-hidden">
                <span className="text-xs font-mono text-slate-400 block">LinkedIn Profile</span>
                <span className="text-sm font-semibold text-slate-800 block truncate">linkedin.com/in/krishna-biswal...</span>
              </div>
            </a>
          </div>
        </div>

        {/* Right Column: Contact Form */}
        <div className="md:col-span-3 bg-slate-50 p-6 rounded-lg border border-slate-200">
          <h3 className="text-lg font-bold text-slate-800 mb-2">Send a Message</h3>
          <p className="text-xs text-slate-500 mb-6">
            Fill out this form to send an email-style message directly to my guestbook database.
          </p>

          <form onSubmit={handleSendMessage} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="contact-name" className="block text-xs font-mono font-medium text-slate-500 mb-1">
                  Your Name
                </label>
                <input
                  id="contact-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Jane Doe"
                  className="w-full text-sm px-3 py-2 bg-white border border-slate-300 rounded shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>

              <div>
                <label htmlFor="contact-email" className="block text-xs font-mono font-medium text-slate-500 mb-1">
                  Your Email
                </label>
                <input
                  id="contact-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. jane@example.com"
                  className="w-full text-sm px-3 py-2 bg-white border border-slate-300 rounded shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label htmlFor="contact-message" className="block text-xs font-mono font-medium text-slate-500 mb-1">
                Message
              </label>
              <textarea
                id="contact-message"
                required
                rows={5}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="What would you like to talk about?"
                className="w-full text-sm px-3 py-2 bg-white border border-slate-300 rounded shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 resize-none"
              />
            </div>

            {error && (
              <p className="text-xs text-red-600 font-mono">{error}</p>
            )}

            {sent && (
              <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-xs flex items-center">
                <Check className="h-4 w-4 mr-2 text-emerald-600 flex-shrink-0" />
                Message sent successfully! Thank you for reaching out.
              </div>
            )}

            <button
              type="submit"
              disabled={sending}
              className="inline-flex items-center justify-center px-5 py-2.5 border border-transparent text-sm font-medium rounded text-white bg-indigo-600 hover:bg-indigo-700 transition-colors disabled:opacity-50 cursor-pointer"
            >
              {sending ? 'Sending...' : 'Send Message'}
              <Send className="ml-2 h-3.5 w-3.5" />
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
