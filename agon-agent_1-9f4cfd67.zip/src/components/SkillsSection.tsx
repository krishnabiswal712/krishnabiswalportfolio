import React from 'react';
import { CheckCircle2, RefreshCw } from 'lucide-react';

// SkillsSection represents Krishna's actual beginner skills.
// It divides them into "Familiar With" and "Currently Learning" to stay realistic.
interface Skill {
  id: number;
  name: string;
  category: string;
  status: string;
}

interface SkillsProps {
  skills: Skill[];
  loading: boolean;
}

export default function SkillsSection({ skills, loading }: SkillsProps) {
  // Group skills by category or status
  const familiarSkills = skills.filter(s => !s.status.toLowerCase().includes('currently learning'));
  const learningSkills = skills.filter(s => s.status.toLowerCase().includes('currently learning'));

  return (
    <section className="py-12 text-left">
      {/* Section Header */}
      <div className="border-b border-slate-200 pb-4 mb-8">
        <h2 className="text-3xl font-bold text-slate-900 font-sans">Skills</h2>
        <p className="text-sm text-indigo-600 font-mono mt-1">import skills_list</p>
      </div>

      {loading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
          <span className="ml-3 font-mono text-sm text-slate-500">Loading skills...</span>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-8">
          {/* Column 1: Core/Familiar Skills */}
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center">
              <CheckCircle2 className="h-5 w-5 mr-2 text-emerald-500" />
              Skills I'm Practicing
            </h3>
            
            <p className="text-sm text-slate-500 leading-relaxed">
              These are concepts and tools I have worked with in my projects. I am comfortable with their basics, 
              but I still look at documentation frequently!
            </p>

            <div className="space-y-3">
              {familiarSkills.map((skill) => (
                <div 
                  key={skill.id} 
                  className="p-4 bg-white rounded-lg border border-slate-200 hover:border-slate-300 transition-colors flex justify-between items-center"
                >
                  <div>
                    <h4 className="font-medium text-slate-800">{skill.name}</h4>
                    <span className="text-xs font-mono text-slate-400">{skill.category}</span>
                  </div>
                  <span className="text-xs font-mono bg-slate-100 text-slate-600 px-2.5 py-1 rounded">
                    {skill.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Column 2: Currently Learning */}
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center">
              <RefreshCw className="h-5 w-5 mr-2 text-indigo-500 animate-spin-slow" />
              What I am Learning Right Now
            </h3>
            
            <p className="text-sm text-slate-500 leading-relaxed">
              I am actively studying these topics. My goal is to understand them deeply and implement them in 
              my upcoming mini-projects.
            </p>

            <div className="space-y-3">
              {learningSkills.map((skill) => (
                <div 
                  key={skill.id} 
                  className="p-4 bg-indigo-50/50 rounded-lg border border-indigo-100 hover:border-indigo-200 transition-colors flex justify-between items-center"
                >
                  <div>
                    <h4 className="font-medium text-indigo-900">{skill.name}</h4>
                    <span className="text-xs font-mono text-indigo-500">{skill.category}</span>
                  </div>
                  <span className="text-xs font-mono bg-indigo-100 text-indigo-700 px-2.5 py-1 rounded">
                    Learning
                  </span>
                </div>
              ))}
              
              {/* Additional future learning targets */}
              <div className="p-4 bg-slate-50/50 rounded-lg border border-dashed border-slate-300 flex justify-between items-center">
                <div>
                  <h4 className="font-medium text-slate-500">Object-Oriented Programming (OOP)</h4>
                  <span className="text-xs font-mono text-slate-400">Python Concepts</span>
                </div>
                <span className="text-xs font-mono bg-slate-100 text-slate-400 px-2.5 py-1 rounded">
                  Up Next
                </span>
              </div>

              <div className="p-4 bg-slate-50/50 rounded-lg border border-dashed border-slate-300 flex justify-between items-center">
                <div>
                  <h4 className="font-medium text-slate-500">Basic Flask/Django (Web APIs)</h4>
                  <span className="text-xs font-mono text-slate-400">Backend Development</span>
                </div>
                <span className="text-xs font-mono bg-slate-100 text-slate-400 px-2.5 py-1 rounded">
                  Up Next
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
