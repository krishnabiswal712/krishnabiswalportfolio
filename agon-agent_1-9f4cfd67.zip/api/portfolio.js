import supabase from './db-client.js';

// This is a Vercel Serverless API Route.
// It acts as a bridge (backend) between our React website (frontend) and our Supabase Database.
// In Python, this is similar to writing a Flask route with @app.route('/api/portfolio', methods=['GET'])
export default async function handler(req, res) {
  // Set headers to allow our React app to talk to this API (CORS)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  // If this is a preflight OPTIONS request, respond with success immediately
  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }

  try {
    // We only accept GET requests to fetch portfolio data
    if (req.method === 'GET') {
      // 1. Fetch all projects from the 'projects' table, sorted by ID
      const { data: projects, error: projectsError } = await supabase
        .from('projects')
        .select('*')
        .order('id', { ascending: true });
      if (projectsError) throw projectsError;

      // 2. Fetch all skills from the 'skills' table, sorted by ID
      const { data: skills, error: skillsError } = await supabase
        .from('skills')
        .select('*')
        .order('id', { ascending: true });
      if (skillsError) throw skillsError;

      // 3. Fetch all learning logs from the 'learning_logs' table, sorted by day_number
      const { data: logs, error: logsError } = await supabase
        .from('learning_logs')
        .select('*')
        .order('day_number', { ascending: true });
      if (logsError) throw logsError;

      // Send the fetched data back to the frontend as a JSON response (like a Python dictionary)
      return res.status(200).json({ projects, skills, logs });
    }
    
    // If the request is not a GET, return Method Not Allowed (405)
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error in portfolio.js:', err);
    res.status(500).json({ error: err.message });
  }
}
