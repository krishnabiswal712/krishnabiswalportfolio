import supabase from './db-client.js';

// This API Route handles our Interactive Guestbook.
// Visitors can leave a message (POST) and read other messages (GET).
// Think of this like a mini Flask application handling database inserts and queries!
export default async function handler(req, res) {
  // CORS headers so our frontend can access this API safely
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }

  try {
    // GET request: Fetch all guestbook messages, latest first
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('guestbook')
        .select('*')
        .order('id', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }

    // POST request: Add a new message left by a visitor
    if (req.method === 'POST') {
      const { name, message } = req.body;

      // Simple validation: make sure both fields have content
      if (!name || !message || name.trim() === '' || message.trim() === '') {
        return res.status(400).json({ error: 'Name and message are required fields.' });
      }

      // Insert the new message into our Supabase 'guestbook' table
      const { data, error } = await supabase
        .from('guestbook')
        .insert({ 
          name: name.trim().substring(0, 50), // Limit name to 50 chars for safety
          message: message.trim().substring(0, 500) // Limit message to 500 chars
        })
        .select()
        .single();
        
      if (error) throw error;
      return res.status(201).json(data);
    }

    // Return 405 if any other method is used
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error in guestbook.js:', err);
    res.status(500).json({ error: err.message });
  }
}
